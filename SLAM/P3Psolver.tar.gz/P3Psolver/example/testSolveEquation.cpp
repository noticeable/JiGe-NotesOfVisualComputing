//Test of P3PSolver

#include <iostream>
using namespace std;

#include <math.h>
#include <stdlib.h>

#include <vnl/algo/vnl_rpoly_roots.h>
#include <vnl/vnl_double_4.h>
#include <vnl/vnl_real_polynomial.h>

#ifdef WIN32
    #pragma comment(lib,"vnl")
    #pragma comment(lib,"vcl")
    #pragma comment(lib,"v3p_netlib.lib")
    #pragma comment(lib,"vnl_algo")
#endif

#include "../P3PSolver.h"
int main(int argc, char* argv[])
{
	//World coordinates of the 3 control points
	double ptw[]={0.105,0.07245,0,-0.105,0.07425,0,-0.105,-0.07425,0};
	//Image coordinates of the 3 points
	double pti[]={256,218,591,224,588,461};
	//Intrinsic parameters of camera
	double p[]={-990.08190,-991.42390,402.16577,291.72516,0,0,0,0};

	P3PSolver p3p;
	p3p.SetIntrinsic(p);
	p3p.SetPointsCorrespondance(ptw,pti);
	p3p.Solve();

	//Output all the probable extrinsic parameters
	for(int i=0;i<p3p.Rs.size() ;i++)
	{
		cout<<"Solution "<<i<<endl;
		cout<<p3p.Rs[i]<<endl;
		cout<<p3p.ts[i]<<endl;
	}

	system("pause");
	return 0;
}

