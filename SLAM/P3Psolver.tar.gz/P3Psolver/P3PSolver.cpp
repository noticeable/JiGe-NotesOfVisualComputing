////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//
// Author:      GU Zhaopeng <zpgu@nlpr.ia.ac.cn>
// Version:     0.0.1
// Date:        2010-10                                         
// Description:   This is an implementation of the classic P3P(Perspective 3-Points) algorithm problem solution 
//				  in the Ransac paper "M. A. Fischler, R. C. Bolles. Random Sample Consensus: A Paradigm for 
//                Model Fitting with Applications to Image Analysis and Automated Cartography. Comm. of the ACM, 
//                Vol 24, pp 381-395, 1981.". The algorithm gives the four probable solutions of the P3P problem 
//                in about 0.1ms, and can be used as input of the consequent RANSAC step. The codes needs the 
//                numerics library VNL which is a part of the widely used computer vision library VXL. One can 
//                download and install it from http://vxl.sourceforge.net/.
//
//
// Copyright (C) 2009-2010 OpenPR 
// All rights reserved. 
// 
// Redistribution and use in source and binary forms, with or without 
// modification, are permitted provided that the following conditions are met: 
// 
//     * Redistributions of source code must retain the above copyright 
//       notice, this list of conditions and the following disclaimer. 
//     * Redistributions in binary form must reproduce the above copyright 
//       notice, this list of conditions and the following disclaimer in the 
//       documentation and/or other materials provided with the distribution. 
//     * Neither the name of OpenPR nor the names of its  
//       contributors may be used to endorse or promote products derived 
//       from this software without specific prior written permission. 
// 
// THIS SOFTWARE IS PROVIDED BY HOLDERS AND CONTRIBUTORS "AS IS" AND ANY 
// EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED 
// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE 
// DISCLAIMED. IN NO EVENT SHALL HOLDER AND CONTRIBUTORS BE LIABLE FOR ANY 
// DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
// (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; 
// LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND 
// ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT 
// (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS 
// SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


#include "P3PSolver.h"

P3PSolver::P3PSolver(void)
{
}

P3PSolver::~P3PSolver(void)
{
}


int P3PSolver::SetIntrinsic(double f_u,double f_v,double u_0,double v_0,double k_1,double k_2,double p_1,double p_2)
{
	fu=f_u;
	fv=f_v;
	u0=u_0;
	v0=v_0;
	k1=k_1;
	k2=k_2;
	p1=p_1;
	p2=p_2;
	return 0;
}

int P3PSolver::SetIntrinsic(double *param)
{
	double* p=param;
	fu=*p;p++;
	fv=*p;p++;
	u0=*p;p++;
	v0=*p;p++;
	k1=*p;p++;
	k2=*p;p++;
	p1=*p;p++;
	p2=*p;p++;

	return 0;
}

int P3PSolver::SetPointsCorrespondance(vnl_vector_fixed<double,3> *ptw,vnl_vector_fixed<double,2> *pti)
{
	for(int i=0;i<3 ;i++)
	{
		W[i]=ptw[i];
		I[i]=pti[i];
	}
	return 0;
}

int P3PSolver::SetPointsCorrespondance(double *ptw,double *pti)
{
	for (int i=0;i<3;i++)
	{
		W[i].copy_in(&ptw[i*3]);
		I[i].copy_in(&pti[i*2]);
	}
	return 0;
}

int P3PSolver::GetCoeffcientofP3P(double Rab, double Rac, double Rbc, 
					   double Cab, double Cac, double Cbc,
					   double &G4, double &G3, double &G2, double &G1, double &G0)
{
	double K1=Rbc*Rbc/(Rac*Rac);
	double K2=Rbc*Rbc/(Rab*Rab);

	G4=(K1*K2-K1-K2)*(K1*K2-K1-K2)-4*K1*K2*Cbc*Cbc;

	G3=4*(K1*K2-K1-K2)*K2*(1-K1)*Cab+
		4*K1*Cbc*((K1*K2+K2-K1)*Cac+2*K2*Cab*Cbc);

	G2=(2*K2*(1-K1)*Cab)*(2*K2*(1-K1)*Cab)+
		2*(K1*K2+K1-K2)*(K1*K2-K1-K2)+
		4*K1*((K1-K2)*Cbc*Cbc+
		(1-K2)*K1*Cac*Cac-2*K2*(1+K1)*Cab*Cac*Cbc);

	G1=4*(K1*K2+K1-K2)*K2*(1-K1)*Cab+
		4*K1*((K1*K2-K1+K2)*Cac*Cbc+2*K1*K2*Cab*Cac*Cac);

	G0=(K1*K2+K1-K2)*(K1*K2+K1-K2)-4*K1*K1*K2*Cac*Cac;

	return 0;
}


int P3PSolver::Solve()
{
	//Compute Rab Rac Rbc in world frame
	vnl_vector_fixed<double,3> VAB,VAC,VBC;
	VAB=W[1]-W[0];
	VAC=W[2]-W[0];
	VBC=W[2]-W[1];

	Rab=VAB.two_norm();
	Rac=VAC.two_norm();
	Rbc=VBC.two_norm();

	//Get norm of each ray in camera frame
	//CA0=[(IA(1,1)-u0)/fu;(IA(2,1)-v0)/fv;1];
	//CB0=[(IB(1,1)-u0)/fu;(IB(2,1)-v0)/fv;1];
	//CC0=[(IC(1,1)-u0)/fu;(IC(2,1)-v0)/fv;1];
	vnl_vector_fixed<double,3> CA,CB,CC;
	CA[0]=(I[0][0]-u0)/fu;CA[1]=(I[0][1]-v0)/fv;CA[2]=1;
	CB[0]=(I[1][0]-u0)/fu;CB[1]=(I[1][1]-v0)/fv;CB[2]=1;
	CC[0]=(I[2][0]-u0)/fu;CC[1]=(I[2][1]-v0)/fv;CC[2]=1;
	
	double Rab1,Rac1,Rbc1;
	CA=CA/CA.two_norm();
	CB=CB/CB.two_norm();
	CC=CC/CC.two_norm();

	Rab1=(CB-CA).two_norm();
	Rac1=(CC-CA).two_norm();
	Rbc1=(CC-CB).two_norm();

	//Compute Calb Calc Cblc using Law of Cosine
	Calb=(2-Rab1*Rab1)/2;
	Calc=(2-Rac1*Rac1)/2;
	Cblc=(2-Rbc1*Rbc1)/2;

	//===========================================================================================
	//Solve equation!
	//===========================================================================================
	
	//Get coefficients of the quartic polynomial equation
	double G4,G3,G2,G1,G0;
	GetCoeffcientofP3P(Rab,Rac,Rbc,Calb,Calc,Cblc,G4,G3,G2,G1,G0);
	
	//Solve it using VNL
	double coeff[5];
	coeff[0]=G4;
	coeff[1]=G3;
	coeff[2]=G2;
	coeff[3]=G1;
	coeff[4]=G0;

	vnl_real_polynomial poly(coeff,5);
	vnl_rpoly_roots ply_roots(poly);
	
	vnl_vector<double> real_roots=ply_roots.real();

	//Temp roots
	//Format: [[x0 a0 b0] [x1 a1 b1]...]
	vector< vnl_vector_fixed<double,3> > rootxab;
	for (int i=0;i<real_roots.size();i++)
	{
		double x=real_roots[i];
		double ifadd=true;
		for (int j=0;j<rootxab.size();j++)
		{
			if (abs(rootxab[j][0]-x)<Epsilon)
			{
				ifadd=false;
			}
		}
		if (ifadd)
		{
			//Compute a b
			double a=Rab/sqrt(x*x-2*x*Calb+1);
			double b=a*x;
			vnl_vector_fixed<double,3> r;
			r[0]=x;
			r[1]=a;
			r[2]=b;
			rootxab.push_back(r);
		}
	}

	double K1=Rbc*Rbc/(Rac*Rac);
	double K2=Rbc*Rbc/(Rab*Rab);

	for (int i=0;i<rootxab.size();i++)
	{
		double delta;
		double m0,m1,p0,p1,q0,q1;

		double x=rootxab[i][0];
		double a=rootxab[i][1];
		double b=rootxab[i][2];

		m0=1-K1;	p0=2*(K1*Calc-x*Cblc);		q0=x*x-K1;
		m1=1;		p1=-2*x*Cblc;				q1=x*x*(1-K2)+2*x*K2*Calb-K2;

		delta=abs(m1*q0-m0*q1);

		if (delta<Epsilon)
		{
			//delta==0
			double y_candidate[2];
			y_candidate[0]=Calc+sqrt(Calc*Calc+(Rac*Rac-a*a)/(a*a));
			y_candidate[1]=Calc-sqrt(Calc*Calc+(Rac*Rac-a*a)/(a*a));

			double c_candidate[2];
			c_candidate[0]=y_candidate[0]*a;
			c_candidate[1]=y_candidate[1]*a;

			for (int j=0;j<2;j++)
			{
				double delta1=abs(b*b+c_candidate[j]*c_candidate[j]-2*b*c_candidate[j]*Cblc-Rbc*Rbc);
				if (delta1<Epsilon)
				{
					double y=y_candidate[j];
					double c=c_candidate[j];
					vnl_vector_fixed<double,5> r;
					r[0]=a;
					r[1]=b;
					r[2]=c;
					r[3]=x;
					r[4]=y;
					roots.push_back(r);
				}
			}
		}
		else
		{
			//delta!=0
			double y=(p1*q0-p0*q1)/(m0*q1-m1*q0);
			double c=y*a;
			vnl_vector_fixed<double,5> r;
			r[0]=a;
			r[1]=b;
			r[2]=c;
			r[3]=x;
			r[4]=y;
			roots.push_back(r);
		}
	}

	//===========================================================================================
	//Get Extrinsics!
	//===========================================================================================

	for (int i=0;i<roots.size();i++)
	{
		double a=roots[i][0];
		double b=roots[i][1];
		double c=roots[i][2];

		//%Get cosine of the angles
		//Clab=(a^2+Rab^2-b^2)/(2*a*Rab);
		//Clac=(a^2+Rac^2-c^2)/(2*a*Rac);
		
		double Clab=(a*a+Rab*Rab-b*b)/(2*a*Rab);
		double Clac=(a*a+Rac*Rac-c*c)/(2*a*Rac);

		//%Get scale along norm vector
		//Raq=a*Clab;
		//Rap=a*Clac;

		double Raq=a*Clab;
		double Rap=a*Clac;

		//%Get norm vector of plane P1 P2
		//VAC=WC-WA;
		//VAB=WB-WA;
		vnl_vector_fixed<double,3> WQ,WP;
		WQ=W[0]+Raq*VAB/VAB.two_norm();
		WP=W[0]+Rap*VAC/VAC.two_norm();
		
		vnl_vector_fixed<double,4> P1,P2,P3;
		vnl_vector_fixed<double,3> NP1,NP2,NP3;
		double DP1,DP2,DP3;

		//%Compute Plane P1 P2 P3
		//NP1=VAB/norm(VAB);
		//DP1=-NP1'*WQ;
		//P1=[NP1;DP1];
		NP1=VAB/VAB.two_norm();
		DP1=-dot_product(NP1,WQ);
		P1.update(NP1);
		P1[3]=DP1;

		//NP2=VAC/norm(VAC);
		//DP2=-NP2'*WP;
		//P2=[NP2;DP2];

		NP2=VAC/VAC.two_norm();
		DP2=-dot_product(NP2,WP);
		P2.update(NP2);
		P2[3]=DP2;

		//%Current we use ACxAB get the norm of P3
		//NP3=crossproduct3d(VAC,VAB)';
		//NP3=NP3/norm(NP3);
		//DP3=-NP3'*WA;
		//P3=[NP3;DP3];

		NP3=vnl_cross_3d(VAC,VAB);
		NP3=NP3/NP3.two_norm();
		DP3=-dot_product(NP3,W[0]);
		P3.update(NP3);
		P3[3]=DP3;

		//BIGA=[P1';P2';P3'];
		vnl_matrix_fixed<double,3,4> BIGA;
		BIGA.set_row(0,P1);
		BIGA.set_row(1,P2);
		BIGA.set_row(2,P3);

		vnl_svd<double> svd_biga(BIGA);

		//WR=null(BIGA,3);
		vnl_vector_fixed<double,4> ns;
		ns=svd_biga.nullvector();
		vnl_vector_fixed<double,3> WR;
		WR=ns.extract(3,0)/ns[3];

		//%Get length of LR
		//Rar=norm(WA-WR);
		//Rlr=sqrt(a^2-Rar^2);

		double Rar,Rlr;
		Rar=(W[0]-WR).two_norm();
		Rlr=sqrt(a*a-Rar*Rar);

		//%Get Position of L in world frame
		//WL=WR+NP3*Rlr;

		vnl_vector_fixed<double,3> WL;
		WL=WR+NP3*Rlr;

		//%Get unprojection ray of image points
		//CA0=[(IA(1,1)-u0)/fu;(IA(2,1)-v0)/fv;1];
		//CB0=[(IB(1,1)-u0)/fu;(IB(2,1)-v0)/fv;1];
		//CC0=[(IC(1,1)-u0)/fu;(IC(2,1)-v0)/fv;1];

		//VCx=CB1-CA1;
		//VCy=CC1-CA1;
		//VCz=crossproduct3d(VCx,VCy)';
		//VCy=crossproduct3d(VCz,VCx)';

		//VCx=VCx/norm(VCx);
		//VCy=VCy/norm(VCy);
		//VCz=VCz/norm(VCz);

		vnl_vector_fixed<double,3> VCX,VCY,VCZ;
		VCX=CB-CA;
		VCY=CC-CA;
		VCZ=vnl_cross_3d(VCX,VCY);
		VCY=vnl_cross_3d(VCZ,VCX);

		VCX=VCX/VCX.two_norm();
		VCY=VCY/VCY.two_norm();
		VCZ=VCZ/VCZ.two_norm();

		//%Get ray in the world frame
		//Vla=WA-WL;
		//Vlb=WB-WL;
		//Vlc=WC-WL;
		vnl_vector_fixed<double,3> Vla,Vlb,Vlc;
		Vla=W[0]-WL;
		Vlb=W[1]-WL;
		Vlc=W[2]-WL;
		Vla=Vla/Vla.two_norm();
		Vlb=Vlb/Vlb.two_norm();
		Vlc=Vlc/Vlc.two_norm();

		//WA1=WL+1*Vla;
		//WB1=WL+1*Vlb;
		//WC1=WL+1*Vlc;
		vnl_vector_fixed<double,3> WA1,WB1,WC1;
		WA1=WL+Vla;
		WB1=WL+Vlb;
		WC1=WL+Vlc;

		//vcx=WB1-WA1;
		//vcy=WC1-WA1;
		//vcz=crossproduct3d(vcx,vcy)';
		//vcy=crossproduct3d(vcz,vcx)';

		//vcx=vcx/norm(vcx);
		//vcy=vcy/norm(vcy);
		//vcz=vcz/norm(vcz);
		vnl_vector_fixed<double,3> vcx,vcy,vcz;
		vcx=WB1-WA1;
		vcy=WC1-WA1;
		vcz=vnl_cross_3d(vcx,vcy);
		vcy=vnl_cross_3d(vcz,vcx);
		vcx=vcx/vcx.two_norm();
		vcy=vcy/vcy.two_norm();
		vcz=vcz/vcz.two_norm();
		
		//R=[VCx VCy VCz]*inv([vcx vcy vcz]);
		vnl_matrix_fixed<double,3,3> R1,R2,R3,Rext;
		R1.set_column(0,VCX);
		R1.set_column(1,VCY);
		R1.set_column(2,VCZ);

		R2.set_column(0,vcx);
		R2.set_column(1,vcy);
		R2.set_column(2,vcz);
		
		R3=vnl_inverse(R2);
		Rext=R1*R3;

		vnl_vector_fixed<double,3> text;
		text=-Rext*WL;

		Rs.push_back(Rext);
		ts.push_back(text);
	}

	return 0;
}

int P3PSolver::GetExtrinsics(vector< vnl_matrix_fixed<double,3,3> > &R_s,
				  vector< vnl_vector_fixed<double,3> > &t_s)
{
	if (Rs.size()!=ts.size())
	{
		cout<<"Error!(Rs.size!=ts.size)"<<endl;
		return -1;
	}

	if (Rs.size()==0)
	{
		cout<<"Error!(No solution founded!)"<<endl;
	}

	for (int i=0;i<Rs.size();i++)
	{
		R_s.push_back(Rs[i]);
		t_s.push_back(ts[i]);
	}

	return 0;
}
