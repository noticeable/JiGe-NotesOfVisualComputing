////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//
// Author:      GU Zhaopeng <zpgu@nlpr.ia.ac.cn>
// Version:     0.0.1
// Date:        2010-10                                         
// Description:   This is an implementation of the classic P3P(Perspective 3-Points) algorithm problem solution 
//				  in the Ransac paper "M. A. Fischler, R. C. Bolles. Random Sample Consensus: A Paradigm for 
//                Model Fitting with Applications to Image Analysis and Automated Cartography. Comm. of the ACM, 
//                Vol 24, pp 381-395, 1981.". The algorithm gives the four probable solutions of the P3P problem 
//                in about 0.1ms, and can be used as input of the consequent RANSAC step. The codes needs the 
//                numerics library VNL which is a part of the widely used computer vision library VXL. One can 
//                download and install it from http://vxl.sourceforge.net/.
//
//
// Copyright (C) 2009-2010 OpenPR 
// All rights reserved. 
// 
// Redistribution and use in source and binary forms, with or without 
// modification, are permitted provided that the following conditions are met: 
// 
//     * Redistributions of source code must retain the above copyright 
//       notice, this list of conditions and the following disclaimer. 
//     * Redistributions in binary form must reproduce the above copyright 
//       notice, this list of conditions and the following disclaimer in the 
//       documentation and/or other materials provided with the distribution. 
//     * Neither the name of OpenPR nor the names of its  
//       contributors may be used to endorse or promote products derived 
//       from this software without specific prior written permission. 
// 
// THIS SOFTWARE IS PROVIDED BY HOLDERS AND CONTRIBUTORS "AS IS" AND ANY 
// EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED 
// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE 
// DISCLAIMED. IN NO EVENT SHALL HOLDER AND CONTRIBUTORS BE LIABLE FOR ANY 
// DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
// (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; 
// LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND 
// ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT 
// (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS 
// SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


#pragma once

#include <vnl/vnl_matrix_fixed.h>
#include <vnl/vnl_vector_fixed.h>

#include <vnl/algo/vnl_rpoly_roots.h>
#include <vnl/vnl_double_4.h>
#include <vnl/vnl_real_polynomial.h>
#include <vnl/vnl_cross.h>
#include <vnl/algo/vnl_svd.h>
#include <vnl/vnl_inverse.h>

#include <iostream>
#include <math.h>
#include <vector>
using namespace std;


//Our zero
#define Epsilon 1.0e-5

class P3PSolver
{
public:
	P3PSolver(void);
public:
	~P3PSolver(void);

	int SetIntrinsic(double f_u,double f_v,double u_0,double v_0,double k_1,double k_2,double p_1,double p_2);
	int SetIntrinsic(double *param);
	int SetPointsCorrespondance(vnl_vector_fixed<double,3> *ptw,vnl_vector_fixed<double,2> *pti);
	int SetPointsCorrespondance(double *ptw,double *pti);
	int Solve();
	int GetExtrinsics(vector< vnl_matrix_fixed<double,3,3> > &R_s,
		vector< vnl_vector_fixed<double,3> > &t_s);

private:
	int GetCoeffcientofP3P(double Rab, double Rac, double Rbc, 
		double Cab, double Cac, double Cbc,
		double &G4, double &G3, double &G2, double &G1, double &G0);

public:
	vector< vnl_matrix_fixed<double,3,3> > Rs;
	vector< vnl_vector_fixed<double,3> > ts;
	//Roots of P3P
	//Format: [[a0 b0 c0 x0 y0],[a1 b1 c1 x1 y1]...]
	vector< vnl_vector_fixed<double,5> > roots;

private:	
	//World & Image coordinates
	vnl_vector_fixed<double,3> W[3];
	vnl_vector_fixed<double,2> I[3];

	//Length of edge between control points
	double Rab,Rac,Rbc;

	//Cosine of angles
	double Calb,Calc,Cblc;
	double Clab,Clac;

	//Intrinsic parameters
	double fu,fv,u0,v0;
	double k1,k2,p1,p2;
};
